package com.spring.recycle.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.recycle.model.dto.MessageDto;

@Repository
public class MessageDaoImpl implements MessageDao {
	
	@Autowired
	private SqlSessionTemplate sqlSession;

	@Override
	public List<MessageDto> getRecvMessage(String message_recvid) {
		List<MessageDto> list = new ArrayList<>();
		try {
			list = sqlSession.selectList(NAMESPACE+"getRecvMessage", message_recvid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public List<MessageDto> getSendMessage(String message_sendid) {
		List<MessageDto> list = new ArrayList<>();
		try {
			list = sqlSession.selectList(NAMESPACE+"getSendMessage", message_sendid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public int insertRecvMessage(MessageDto dto) {
		int res = 0;
		try {
			res = sqlSession.insert(NAMESPACE+"insertRecvMessage", dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return res;
	}

	@Override
	public int insertSendMessage(MessageDto dto) {
		int res = 0;
		try {
			res = sqlSession.insert(NAMESPACE+"insertSendMessage", dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return res;
	}

	@Override
	public int unreadMsgCount(String message_recvid) {
		int count = 0;
		try {
			count = sqlSession.selectOne(NAMESPACE+"unreadMsgCount", message_recvid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public MessageDto recvDetail(int message_no) {
		MessageDto dto = null;
		try {
			dto = sqlSession.selectOne(NAMESPACE+"recvDetail", message_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto;
	}

	@Override
	public MessageDto sendDetail(int message_no) {
		MessageDto dto = null;
		try {
			dto = sqlSession.selectOne(NAMESPACE+"sendDetail", message_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dto;
	}

	@Override
	public int updateMessage(int message_no) {
		int res = 0;
		try {
			res = sqlSession.update(NAMESPACE+"updateMessage", message_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return res;
	}

	@Override
	public int deleteRecvMessage(int[] message_noList) {
		int res = 0;
		try {
			res = sqlSession.delete(NAMESPACE+"deleteRecvMessage", message_noList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public int deleteSendMessage(int[] message_noList) {
		int res = 0;
		try {
			res = sqlSession.delete(NAMESPACE+"deleteSendMessage", message_noList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
}

