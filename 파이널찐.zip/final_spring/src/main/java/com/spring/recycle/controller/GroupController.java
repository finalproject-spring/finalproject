package com.spring.recycle.controller;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.recycle.model.biz.GroupBiz;
import com.spring.recycle.model.biz.GroupBizImpl;
import com.spring.recycle.model.dto.GroupDto;


@Controller
public class GroupController {
	
	@Autowired
	private GroupBiz biz = new GroupBizImpl();
	
	private static final Logger logger = LoggerFactory.getLogger(GroupController.class);
	
	@RequestMapping(value = "/group_list.do", method = RequestMethod.GET)
	public String selectList(Model model) {
		model.addAttribute("list", biz.list());
		
		return "group/grouplist";
	}
	
	@RequestMapping("/group_insertform.do")
	public String insertForm() {
		return "group/groupinsert";
	}
	
	@RequestMapping(value = "/group_insertres.do" , method = RequestMethod.POST)
	public String insertRes(Model model , @ModelAttribute GroupDto dto , HttpServletRequest request , HttpServletResponse response) throws IOException {
		
		int res = 0;
		res = biz.write(dto);
		
		logger.info("==========dto: " +dto+"=============================res : " + res);
		PrintWriter out = response.getWriter();
		response.setContentType("text/html; charset=UTF-8");
		
		if(res>0) {
			out.print("<script>alert('게시글이 등록되었습니다..'); location.href='group_list.do';</script>");
		}else {
			out.println("<script>alert('게시글이 등록을 실패하였습니다.');</script>");
			return "group/groupinsert";
		}
		return "group/grouplist";
	}

}
