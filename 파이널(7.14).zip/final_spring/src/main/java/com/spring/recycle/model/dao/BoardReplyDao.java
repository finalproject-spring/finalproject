package com.spring.recycle.model.dao;

public interface BoardReplyDao {

}
