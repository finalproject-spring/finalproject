package com.spring.recycle.model.dao;

import java.util.List;

import com.spring.recycle.model.dto.FundingDto;

public interface FundingDao {
	
	String NAMESPACE = "funding.";
	
	public List<FundingDto> fundingList();
	public List<FundingDto> fundingEList();
	public FundingDto fundingDetail(int funding_no);
	public int fundingInsert(FundingDto dto);
	public int fundingUpdate(FundingDto dto);
	public int fundingDelete(int funding_no);
	public List<FundingDto> fundingFilter(String funding_filter);
	public List<FundingDto> fundingEFilter(String funding_filter);

}
