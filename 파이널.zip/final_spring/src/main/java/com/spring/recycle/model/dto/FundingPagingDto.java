package com.spring.recycle.model.dto;

public class FundingPagingDto {
	
	private int limit;
	private int page;
	private int startpage;
	private int endpage;
	private int maxpage;

	
	
	public FundingPagingDto() {
	}

	public FundingPagingDto(int limit, int page, int startpage, int endpage, int maxpage) {
		this.limit = limit;
		this.page = page;
		this.startpage = startpage;
		this.endpage = endpage;
		this.maxpage = maxpage;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getStartpage() {
		return startpage;
	}

	public void setStartpage(int startpage) {
		this.startpage = startpage;
	}

	public int getEndpage() {
		return endpage;
	}

	public void setEndpage(int endpage) {
		this.endpage = endpage;
	}

	public int getMaxpage() {
		return maxpage;
	}

	public void setMaxpage(int maxpage) {
		this.maxpage = maxpage;
	}
	
	
	

}
