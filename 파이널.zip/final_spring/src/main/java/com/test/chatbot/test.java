package com.test.chatbot;

import java.io.IOException;

public class test {

	public static void main(String[] args) throws IOException {
		chatbot.chatbot();
	}
}
