package com.test.chatbot;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;

import javax.servlet.http.HttpSession;


public class chatbot {
	
	public static void chatbot() throws IOException {
		//https://dialogflow.googleapis.com/v2/projects/project-id/agent/sessions/session-id:detectIntent
		HttpSession session = null;
		String projectid = "final-project-319907";
		String sessionid = UUID.randomUUID().toString();
//		session.setAttribute("chatsession", sessionid);
		
		String responBody = null;
		String dialog_url = "https://dialogflow.googleapis.com/v2/projects/"+projectid+"/agent/sessions/"+sessionid+":detectIntent";
		URL url = new URL(dialog_url);
	    HttpURLConnection con = (HttpURLConnection)url.openConnection();
	    con.setRequestMethod("POST");
		con.setDoOutput(true);
	    int responseCode = con.getResponseCode();
	    System.out.println(responseCode);
	    
	}

}
