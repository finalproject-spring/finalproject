package com.spring.recycle.common.aop;

public class LogAop {

}
